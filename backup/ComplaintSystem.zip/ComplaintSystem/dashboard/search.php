<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Search</title>
    <link rel="stylesheet" href="https://maxcdm.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container" style="max-width:50%;">
        <div class="text-center mt-5 mb-4">
            <h2>PHP Mysql Live Search</h2>
        </div>

        <input type="text" class="form-control" name="live_search" id="live_search" autocomplete="off" placeholder="Search...">
    </div>
</body>
</html>