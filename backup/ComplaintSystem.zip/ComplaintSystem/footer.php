<!-- Footer starts here -->
<footer class="page-footer font-small text-light" style="background: linear-gradient(to left bottom, #8e2de2, #111 60%); box-shadow: 0px 0px 10px 4px #000;">

  <div style="background: linear-gradient(to left, #8e2de2 , #111 70%); box-shadow: 0px 0px 4px 1px #000;">
    <div class="container">

      <!-- Grid row-->
      <div class="row py-3 d-flex align-items-center" style="display: flex !important;
    flex-direction: row-reverse;">

        <!-- Grid column -->
        <div class="col-md-6 col-lg-5 text-center text-md-left mb-3 mb-md-0" >
          <h6 class="mb-0">Ragama Police Unit</h6>
        </div>
        <!-- Grid column -->


        <!-- Grid column -->
      </div>
      <!-- Grid row-->

    </div>
  </div>

  <!-- Footer Links -->
  <div class="container text-center text-md-left mt-5">
    <!-- Grid row -->
    <div class="row mt-1">
      <!-- Grid column -->
      <div class="col-md-4 col-lg-4 col-xl-4 mx-auto mb-1">
        <!-- Content -->
        <h6 class="text-uppercase font-weight-bold" id="contact">Complaint Portal</h6>
        <hr class="deep-purple accent-2 mb-3 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>
        2WMF+XMR, Thewatta Rd, Ragama
        </p>

        <p>
          <i class="fa fa-phone mr-2"></i> + 94 11-2957197
        </p>
        <p>
          <i class="fa fa-phone mr-2"></i> + 94 112 958 222
      </div>
      <!-- Grid column -->

      <!-- Grid column 
      <div class="col-md-4 col-lg-4 col-xl-4 mx-auto mb-1">-->
        <!-- Links 
        <h6 class="text-uppercase font-weight-bold">Products</h6>
        <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>
          <a href="#!"><img src="./assets/img/apple_store.png" class="app-store" alt="Apple Store"></a>
        </p>
        <p>
          <a href="#!"><img src="./assets/img/google_store.png" class="app-store" alt="Google Store"></a>
        </p>
      </div>-->
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-4 col-lg-4 col-xl-4 mx-auto mb-1">
        <!-- Links -->
        <h6 class="text-uppercase font-weight-bold">Suggestions</h6>
        <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <div id="suggestionAlert"></div>
        <form id="suggestionForm" onsubmit="suggestions()">
          <div class="form-group">
            <label for="suggestionFormTextarea">Your Valuable Suggestion</label>
            <textarea class="form-control" id="suggestionText" rows="3"></textarea>
          </div>
          <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" id="suggestionCheck">
            <label class="form-check-label" for="suggestionCheck">Check to Submit</label>
          </div>
          <button type="submit" class="btn" style="background: rgb(255, 255, 255); color: #eb0000; font-weight: bolder;">Submit</button>
        </form>
      </div>
      <!-- Grid column -->
    </div>
    <!-- Grid row -->
  </div>
  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3" id="footer-copyright">&copy; <script>
      document.getElementById('footer-copyright').innerHTML += new Date().getFullYear();
    </script> Copyright |
    <a class="text" href="#" style="color: #8e2de2;"> UnamiTech Solutions</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer ends here -->

<?php include_once('./scripts.php'); ?>